# Zebra Helm Chart

Zebra is a data management platform for realtime data collection and analysis; It connects to the Ona Data API.

The deployment can contain two containers depending on whether the nginx side car is enabled the names of the containers are:

- zebra: The main zebra application
- zebra-nginx-sidecar: The Nginx proxy used to serve static files and route requests to the zebra container.

## FAQ

Q: How do I view logs on Zebra ?

A: Logs for the deployment can be viewed in two ways depending on how the chart is deployed

  - If the chart is deployed with the Nginx sidecar enabled, the logs can be viewed via:

      ```sh
      kubectl logs pod/<pod-name> <container-name i.e zebra, zebra-nginx-sidecar>
      ```

  - If the chart is deployed without the Nginx sidecar, the logs can be viewed via:

      ```sh
      kubectl logs pod/<pod-name>
      ```

Q: How can one execute commands within the containers when the nginx sidecar is enabled ?

A: Commands can be executed in specific containers via the `kubectl exec` command. i.e

  ```sh
  kubectl exec -it pod/<pod-name> -c zebra -- /bin/bash  # Starts a bash terminal on the zebra container
  ```

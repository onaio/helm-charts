{{/*
Expand the name of the chart.
*/}}
{{- define "onadata.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "onadata.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "onadata.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "onadata.labels" -}}
helm.sh/chart: {{ include "onadata.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "onadata.apiLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.apiSelectorLabels" . }}
{{- end }}

{{- define "onadata.submissionsApiLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.submissionsApiSelectorLabels" . }}
{{- end }}

{{- define "onadata.briefcaseApiLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.briefcaseApiSelectorLabels" . }}
{{- end }}

{{- define "onadata.workerLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.workerSelectorLabels" . }}
{{- end }}

{{- define "onadata.schedulerLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.workerSelectorLabels" . }}
{{- end }}

{{- define "onadata.exporterLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.exporterSelectorLabels" . }}
{{- end }}

{{- define "onadata.djangoExporterLabels" -}}
{{ include "onadata.labels" . }}
{{ include "onadata.djangoExporterSelectorLabels" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "onadata.apiSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-api
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.api -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "onadata.submissionsApiSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-submissions-api
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.submissionsApi -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "onadata.briefcaseApiSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-briefcase-api
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.briefcaseApi -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "onadata.workerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-worker
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.worker -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "onadata.schedulerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-scheduler
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.scheduler -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "onadata.exporterSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-celery-exporter
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.celeryExporter -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "onadata.djangoExporterSelectorLabels" -}}
app.kubernetes.io/name: {{ include "onadata.name" . }}-django-exporter
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: {{ include "onadata.name" . }}
{{- with .Values.extraSelectorLabels.celeryExporter -}}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "onadata.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "onadata.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

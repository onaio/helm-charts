import os
import json
import sys
from celery.schedules import crontab
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration
from sentry_sdk.integrations.celery import CeleryIntegration
from onadata.settings.common import *

from urllib.parse import urljoin

true_vals = ["True", "true"]


REGISTRATION_OPEN = os.environ.get("REGISTRATION_OPEN") in true_vals
# --------------------------------------------------------------------
# Host Configs
# --------------------------------------------------------------------

HOST_URL = os.environ.get("HOST_URL")

# --------------------------------------------------------------------
# Database Configs
# --------------------------------------------------------------------


def str_to_dict(val):
    try:
        return json.loads(val)
    except (TypeError, ValueError):
        return val


DATABASES = {
    "default": {
        "ENGINE": os.environ.get("DB_ENGINE", "django.contrib.gis.db.backends.postgis"),
        "NAME": os.environ.get("MAIN_DB_NAME"),
        "USER": os.environ.get("DB_USER"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        "HOST": os.environ.get("DB_HOST"),
        "PORT": os.environ.get("DB_PORT"),
        "DISABLE_SERVER_SIDE_CURSORS": os.environ.get("DB_DISABLE_SERVER_SIDE_CURSORS"),
    },
    "replica1": {
        "ENGINE": os.environ.get("DB_ENGINE", "django.contrib.gis.db.backends.postgis"),
        "NAME": os.environ.get("REPLICA_ONE_DB_NAME"),
        "USER": os.environ.get("DB_USER"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        "HOST": os.environ.get("DB_HOST"),
        "PORT": os.environ.get("DB_PORT"),
        "DISABLE_SERVER_SIDE_CURSORS": os.environ.get("DB_DISABLE_SERVER_SIDE_CURSORS"),
    },
    "replica2": {
        "ENGINE": os.environ.get("DB_ENGINE", "django.contrib.gis.db.backends.postgis"),
        "NAME": os.environ.get("REPLICA_TWO_DB_NAME"),
        "USER": os.environ.get("DB_USER"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        "HOST": os.environ.get("DB_HOST"),
        "PORT": os.environ.get("DB_PORT"),
        "DISABLE_SERVER_SIDE_CURSORS": os.environ.get("DB_DISABLE_SERVER_SIDE_CURSORS"),
    },
}
SLAVE_DATABASES = ["replica1", "replica2"]
DATABASE_ROUTERS = ["multidb.PinningMasterSlaveRouter"]
MULTIDB_PINNING_SECONDS = os.environ.get("MULTIDB_PINNING_SECONDS", 10)
# --------------------------------------------------------------------
# Cache Configs
# --------------------------------------------------------------------
CACHES = {
    "default": {
        "BACKEND": os.environ.get("CACHE_BACKEND"),
        "LOCATION": os.environ.get("CACHE_LOCATION"),
        "KEY_PREFIX": "onadata",
    }
}

# --------------------------------------------------------------------
# USER Creation via API
# --------------------------------------------------------------------
DISABLE_CREATING_USERS = os.environ.get("DISABLE_CREATING_USERS")

# --------------------------------------------------------------------
# General Configs
# --------------------------------------------------------------------
REST_FRAMEWORK = {
    # Use hyperlinked styles by default.
    # Only used if the `serializer_class` attribute is not set on a view.
    "DEFAULT_MODEL_SERIALIZER_CLASS": os.environ.get(
        "DEFAULT_MODEL_SERIALIZER_CLASS"
    ).split(" ")
    if os.environ.get("DEFAULT_MODEL_SERIALIZER_CLASS")
    else "rest_framework.serializers.HyperlinkedModelSerializer",
    # Use Django's standard `django.contrib.auth` permissions,
    # or allow read-only access for unauthenticated users.
    "DEFAULT_PERMISSION_CLASSES": os.environ.get("DEFAULT_PERMISSION_CLASSES").split(
        " "
    )
    if os.environ.get("DEFAULT_PERMISSION_CLASSES")
    else (
        "rest_framework.permissions.IsAuthenticatedOrReadOnly",
        "rest_framework.permissions.DjangoModelPermissions",
    ),
    "DEFAULT_AUTHENTICATION_CLASSES": os.environ.get(
        "DEFAULT_AUTHENTICATION_CLASSES"
    ).split(" ")
    if os.environ.get("DEFAULT_AUTHENTICATION_CLASSES")
    else (
        "onadata.libs.authentication.DigestAuthentication",
        "onadata.libs.authentication.SSOHeaderAuthentication",
        "onadata.libs.authentication.TempTokenAuthentication",
        "onadata.libs.authentication.EnketoTokenAuthentication",
        "oauth2_provider.contrib.rest_framework.OAuth2Authentication",
        "rest_framework.authentication.SessionAuthentication",
        "rest_framework.authentication.TokenAuthentication",
        "rest_framework.authentication.BasicAuthentication",
    ),
    "DEFAULT_RENDERER_CLASSES": os.environ.get("DEFAULT_RENDERER_CLASSES").split(" ")
    if os.environ.get("DEFAULT_RENDERER_CLASSES")
    else (
        "rest_framework.renderers.JSONRenderer",
        "rest_framework_jsonp.renderers.JSONPRenderer",
        "rest_framework.renderers.BrowsableAPIRenderer",
        "rest_framework_csv.renderers.CSVRenderer",
    ),
}
if os.environ.get("MIDDLEWARE"):
    MIDDLEWARE = os.environ.get("MIDDLEWARE").split(" ")
else:
    MIDDLEWARE = (
        "multidb.middleware.PinningRouterMiddleware",
        "django.middleware.http.ConditionalGetMiddleware",
        "corsheaders.middleware.CorsMiddleware",
        "django.middleware.common.CommonMiddleware",
        "django.contrib.sessions.middleware.SessionMiddleware",
        "onadata.libs.utils.middleware.LocaleMiddlewareWithTweaks",
        "django.middleware.csrf.CsrfViewMiddleware",
        "django.contrib.auth.middleware.AuthenticationMiddleware",
        "django.contrib.messages.middleware.MessageMiddleware",
        "onadata.libs.utils.middleware.HTTPResponseNotAllowedMiddleware",
        "onadata.libs.utils.middleware.OperationalErrorMiddleware",
        "django.middleware.clickjacking.XFrameOptionsMiddleware",
    )
SECRET_KEY = os.environ.get("SECRET_KEY")
JWT_ALGORITHM = "HS256"
JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY")
# Storage
STORAGES = {
    "default": {
        "BACKEND": os.environ.get(
            "DEFAULT_FILE_STORAGE", "storages.backends.s3boto3.S3Boto3Storage"
        )
    },
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"},
}
FORM_RENDERER = "django.forms.renderers.TemplatesSetting"
OAUTH2_PROVIDER_APPLICATION_MODEL = "oauth2_provider.Application"

OAUTH2_PROVIDER["PKCE_REQUIRED"] = False
OAUTH2_PROVIDER["AUTHORIZATION_CODE_EXPIRE_SECONDS"] = 600

if os.environ.get("OPENID_M2M_IMPORT_USER"):
    OPENID_IMPORT_USER = {
        "ENABLED": os.environ.get("OPENID_M2M_IMPORT_USER") in true_vals,
        "TOKEN_ENDPOINT": os.environ.get("OPENID_M2M_TOKEN_ENDPOINT"),
        "SEARCH_ENDPOINT": os.environ.get("OPENID_M2M_SEARCH_ENDPOINT"),
        "CLIENT_ID": os.environ.get("OPENID_M2M_CLIENT_ID"),
        "CLIENT_SECRET": os.environ.get("OPENID_M2M_CLIENT_SECRET"),
        "SCOPE": os.environ.get("OPENID_M2M_SCOPE"),
        "QUERY_PARAM": os.environ.get("OPENID_M2M_QUERY_PARAM", "q"),
        "MAP_CLAIM_TO_MODEL": {
            "email": "email",
            "given_name": "first_name",
            "family_name": "last_name",
            "preferred_username": "username",
        }
        if not os.environ.get("OPENID_M2M_MAP_CLAIM_TO_MODEL")
        else dict(
            [
                k_v.split(":")
                for k_v in os.environ.get("OPENID_M2M_MAP_CLAIM_TO_MODEL").split(" ")
            ]
        ),  # example "given_name:first_name family_name:last_name",
        "SEARCH_RESULTS_PATH": os.environ.get("OPENID_M2M_SEARCH_RESULTS_PATH"),
    }

if os.environ.get("OPENID_AUTH_SERVER_NAME"):
    OPENID_CONNECT_AUTH_SERVERS = {
        os.environ.get("OPENID_AUTH_SERVER_NAME"): {
            "AUTHORIZATION_ENDPOINT": os.environ.get("OPENID_AUTHORIZATION_ENDPOINT"),
            "CLIENT_ID": os.environ.get("OPENID_CLIENT_ID"),
            "CLIENT_SECRET": os.environ.get("OPENID_CLIENT_SECRET"),
            "REDIRECT_URI": os.environ.get("OPENID_CALLBACK_REDIRECT_URI"),
            "TARGET_URL_AFTER_AUTH": os.environ.get("OPENID_TARGET_URL_AFTER_AUTH"),
            "TARGET_URL_AFTER_LOGOUT": os.environ.get("OPENID_TARGET_URL_AFTER_LOGOUT"),
            "TOKEN_ENDPOINT": os.environ.get("OPENID_TOKEN_ENDPOINT"),
            "JWKS_ENDPOINT": os.environ.get("OPENID_JWKS_ENDPOINT"),
            "USER_INFO_ENDPOINT": os.environ.get("OPENID_USER_INFO_ENDPOINT"),
            "VERIFY_ACCESS_TOKEN": os.environ.get("OPENID_VERIFY_ACCESS_TOKEN", "True")
            in true_vals,
            "END_SESSION_ENDPOINT": os.environ.get("OPENID_END_SESSION_ENDPOINT"),
            "SCOPE": os.environ.get("OPENID_SCOPE", "openid profile email"),
            "RESPONSE_TYPE": os.environ.get("OPENID_RESPONSE_TYPE", "code"),
            "USE_NONCES": os.environ.get("OPENID_USE_NONCES", "True") in true_vals,
            "RESPONSE_MODE": os.environ.get("OPENID_RESPONSE_MODE", "form_post"),
            "USE_PKCE": os.environ.get("OPENID_USE_PKCE", "False") in true_vals,
            "REQUEST_MODE": os.environ.get("OPENID_REQUEST_MODE", "query"),
            "NONCE_CACHE_TIMEOUT": int(
                os.environ.get("OPENID_NONCE_CACHE_TIMEOUT", "1800")
            ),
            "PKCE_CODE_CHALLENGE_METHOD": os.environ.get(
                "OPENID_PKCE_CODE_CHALLENGE_METHOD", "S256"
            ),
            "PKCE_CODE_CHALLENGE_TIMEOUT": int(
                os.environ.get("OPENID_PKCE_CODE_CHALLENGE_TIMEOUT", "600")
            ),
            "PKCE_CODE_VERIFIER_LENGTH": int(
                os.environ.get("OPENID_PKCE_CODE_VERIFIER_LENGTH", "64")
            ),
        },
    }

if os.environ.get("JWT_SECRET_KEY"):
    OPENID_CONNECT_VIEWSET_CONFIG = {
        "JWT_SECRET_KEY": os.environ.get("OPENID_JWT_SECRET_KEY"),
        "JWT_ALGORITHM": os.environ.get("OPENID_JWT_ALGORITHM", "HS256"),
        "USE_EMAIL_USERNAME": os.environ.get("OPENID_USE_EMAIL_USERNAME", "True")
        in true_vals,
        "REQUIRED_USER_CREATION_FIELDS": ["email", "first_name", "username"]
        if not os.environ.get("OPENID_REQUIRED_USER_CREATION_FIELDS")
        else os.environ.get("OPENID_REQUIRED_USER_CREATION_FIELDS").split(" "),
        "USER_CREATION_FIELDS": ["email", "first_name", "last_name", "username"]
        if not os.environ.get("OPENID_USER_CREATION_FIELDS")
        else os.environ.get("OPENID_USER_CREATION_FIELDS").split(" "),
        "MAP_CLAIM_TO_MODEL": {"given_name": "first_name", "family_name": "last_name"}
        if not os.environ.get("OPENID_MAP_CLAIM_TO_MODEL")
        else dict(
            [
                k_v.split(":")
                for k_v in os.environ.get("OPENID_MAP_CLAIM_TO_MODEL").split(" ")
            ]
        ),  # example "given_name:first_name family_name:last_name"
        "SPLIT_NAME_CLAIM": os.environ.get("OPENID_SPLIT_NAME_CLAIM", "False")
        in true_vals,
        "USER_UNIQUE_FILTER_FIELD": os.environ.get(
            "OPENID_USER_UNIQUE_FILTER_FIELD", "username"
        ),
        "USE_SSO_COOKIE": os.environ.get("OPENID_USE_SSO_COOKIE", "True") in true_vals,
        "SSO_COOKIE_DATA": os.environ.get("OPENID_SSO_COOKIE_DATA", "email"),
        "SSO_COOKIE_MAX_AGE": None,
        "SSO_COOKIE_DOMAIN": os.environ.get("OPENID_SSO_COOKIE_DOMAIN", ".ona.io"),
        "USE_AUTH_BACKEND": os.environ.get("OPENID_USE_AUTH_BACKEND", "True")
        in true_vals,
        "AUTH_BACKEND": os.environ.get(
            "AUTH_BACKEND", "onadata.apps.main.backends.ModelBackend"
        ),
        "REDIRECT_AFTER_AUTH": os.environ.get("OPENID_REDIRECT_AFTER_AUTH"),
        "USE_RAPIDPRO_VIEWSET": os.environ.get("OPNEID_USE_RAPIDPRO_VIEWSET", "False")
        in true_vals,
        "AUTO_CREATE_USER": os.environ.get("OPENID_AUTO_CREATE_USER", "True")
        in true_vals,
        # A map containing a field as a key and a map containing the regex and optional help_text strings as it's value
        # that's used to validate all field inputs retrieved for the particular key
        "FIELD_VALIDATION_REGEX": {
            "username": {
                "regex": os.environ.get(
                    "OPENID_FIELD_VALIDATION_REGEX", r"(?!^\d+$)^.+$"
                ),
                "help_text": os.environ.get(
                    "OPENID_FIELD_VALIDATION_REGEX_HELP_TEXT",
                    "Username should only contain alpha numeric characters",
                ),
            }
        },
    }


ALLOWED_HOSTS = ["*"]
# ADMINS = ()
CUSTOM_MAIN_URLS = set()
EXPORT_TASK_PROGRESS_UPDATE_BATCH = 100
ZIP_EXPORT_COUNTDOWN = 3600  # 43200 seconds by default
# Time zone settings
TIME_ZONE = os.environ.get("TIME_ZONE", "UTC")
# Time in minutes to lock out user from account
LOCKOUT_TIME = 30 * 60
MAX_LOGIN_ATTEMPTS = 10
# Set Cache-Control: max-age=30 seconds
CACHE_MIXIN_SECONDS = 30
INSTALLED_APPS += ("django.forms",)
X_FRAME_OPTIONS = "SAMEORIGIN"
# mainly for data submission attachments, the max size we can accept
DEFAULT_CONTENT_LENGTH = int(
    float(os.environ.get("DEFAULT_CONTENT_LENGTH", "100000000"))
)
EXTRA_COLUMNS = ["_xform_id"]
SUPPORT_EMAIL = os.environ.get("SUPPORT_EMAIL", "support@ona.io")
if os.environ.get("SUPPORTED_MEDIA_UPLOAD_TYPES"):
    SUPPORTED_MEDIA_UPLOAD_TYPES = os.environ.get("SUPPORTED_MEDIA_UPLOAD_TYPES").split(
        " "
    )
else:
    SUPPORTED_MEDIA_UPLOAD_TYPES = [
        "audio/mp3",
        "audio/mpeg",
        "audio/wav",
        "audio/x-m4a",
        "image/jpeg",
        "image/png",
        "image/svg+xml",
        "text/csv",
        "text/json",
        "video/3gpp",
        "video/mp4",
        "application/json",
        "application/geo+json",
        "application/pdf",
        "application/msword",
        "application/vnd.ms-excel",
        "application/vnd.ms-powerpoint",
        "application/vnd.oasis.opendocument.text",
        "application/vnd.oasis.opendocument.spreadsheet",
        "application/vnd.oasis.opendocument.presentation",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/zip",
    ]

# ------------------------------------------------------------------
# File System Storage
# ------------------------------------------------------------------

if (
    os.environ.get("DEFAULT_FILE_STORAGE", "storages.backends.s3boto3.S3Boto3Storage")
    == "django.core.files.storage.FileSystemStorage"
):
    MEDIA_URL = os.environ.get("MEDIA_URL")
    MEDIA_ROOT = os.environ.get(
        "MEDIA_ROOT", os.path.join("/", "srv", "onadata", "media/")
    )

USE_CUSTOM_TEMPLATE = os.environ.get("USE_CUSTOM_TEMPLATE") in true_vals
if USE_CUSTOM_TEMPLATE:
    CUSTOM_TEMPLATE_DIR = os.environ.get("CUSTOM_TEMPLATE_DIR")
    if isinstance(CUSTOM_TEMPLATE_DIR, str):
        # site templates overrides
        TEMPLATES[0]["DIRS"] = [
            os.path.join(CUSTOM_TEMPLATE_DIR, "templates"),
        ] + TEMPLATES[0]["DIRS"]
        # site static files path
        STATICFILES_DIRS += (os.path.join(CUSTOM_TEMPLATE_DIR, "static"),)

# ------------------------------------------------------------------
# Flags
# ------------------------------------------------------------------
SITE_READ_ONLY = os.environ.get("SITE_READ_ONLY") in true_vals
DEBUG = os.environ.get("DEBUG") in true_vals
TESTING_MODE = os.environ.get("TESTING_MODE") in true_vals
APPS_DIR = os.environ.get("APPS_DIR") in true_vals
TAGGIT_CASE_INSENSITIVE = os.environ.get("TAGGIT_CASE_INSENSITIVE") in true_vals
STREAM_DATA = os.environ.get("STREAM_DATA", "True") in true_vals
VERIFY_SSL = os.environ.get("VERIFY_SSL") in true_vals
REQUIRE_ODK_AUTHENTICATION = os.environ.get("REQUIRE_ODK_AUTHENTICATION") in true_vals
MESSAGING_ASYNC_NOTIFICATION = (
    os.environ.get("MESSAGING_ASYNC_NOTIFICATION") in true_vals
)
ALLOW_PUBLIC_DATASETS = os.environ.get("ALLOW_PUBLIC_DATASETS") in true_vals
ASYNC_POST_SUBMISSION_PROCESSING_ENABLED = (
    os.environ.get("ASYNC_POST_SUBMISSION_PROCESSING_ENABLED") in true_vals
)
ORG_ON_CREATE_IS_ACTIVE = os.environ.get("ORG_ON_CREATE_IS_ACTIVE") in true_vals
TEMPLATES[0]["OPTIONS"]["debug"] = os.environ.get("DEBUG") in true_vals

# --------------------------------------------------------------------
# ODK Key Configs
# --------------------------------------------------------------------
ODK_TOKEN_FERNET_KEY = os.environ.get("ODK_TOKEN_FERNET_KEY")
ODK_KEY_LIFETIME = os.environ.get("ODK_TOKEN_LIFETIME", 365)
ODK_TOKEN_LENGTH = os.environ.get("ODK_TOKEN_LENGTH", 7)

# --------------------------------------------------------------------
# External Service(s) Configs
# --------------------------------------------------------------------
KPI_FORMBUILDER_URL = os.environ.get("KPI_FORMBUILDER_URL")
KPI_INTERNAL_SERVICE_URL = os.environ.get("KPI_INTERNAL_URL")

ZEBRA_URL = os.environ.get("ZEBRA_URL")
ENKETO_API_SALT = os.environ.get("ENKETO_API_SALT")
ENKETO_API_TOKEN = os.environ.get("ENKETO_API_TOKEN")
ENKETO_AUTH_COOKIE_DOMAIN = os.environ.get("ENKETO_AUTH_COOKIE_DOMAIN")
ENKETO_CLIENT_LOGIN_URL = str_to_dict(
    os.environ.get("ENKETO_CLIENT_LOGIN_URL", f'{{"*": "{ZEBRA_URL}/login"}}')
)
ENKETO_URL = os.environ.get("ENKETO_URL", "")
ENKETO_API_SURVEY_PATH = os.environ.get("ENKETO_API_SURVEY_PATH", "/api_v2/survey")
ENKETO_PREVIEW_URL = urljoin(ENKETO_URL, ENKETO_API_SURVEY_PATH + "/preview")
ENKETO_API_INSTANCE_IFRAME_URL = ENKETO_URL + "api_v1/instance/iframe"
ENKETO_API_INSTANCE_IFRAME_URL = urljoin(ENKETO_URL, "api_v2/instance/iframe")
ENKETO_API_SURVEY_PATH = os.environ.get("ENKETO_API_SURVEY_PATH", "/api_v2/survey")
ENKETO_API_INSTANCE_PATH = os.environ.get(
    "ENKETO_API_INSTANCE_PATH", "/api_v2/instance"
)
ENKETO_PREVIEW_URL = urljoin(ENKETO_URL, ENKETO_API_SURVEY_PATH + "/preview")
ENKETO_API_SURVEY_PATH = urljoin(ENKETO_URL, ENKETO_API_SURVEY_PATH + "/offline")
ENKETO_AUTH_COOKIE = os.environ.get("ENKETO_AUTH_COOKIE", "__enketo")
ENKETO_META_UID_COOKIE = os.environ.get("ENKETO_META_UID_COOKIE", "__enketo_meta_uid")

# --------------------------------------------------------------------
# Celery Configs
# --------------------------------------------------------------------
BROKER_URL = os.environ.get("CELERY_BROKER_URL")
CELERY_WORKER_SEND_TASK_EVENTS = (
    os.environ.get("CELERY_WORKER_SEND_TASK_EVENTS") in true_vals
) or True
CELERY_TASK_SEND_SENT_EVENT = (
    os.environ.get("CELERY_TASK_SEND_SENT_EVENT") in true_vals
) or True
CELERY_BROKER_URL = BROKER_URL
CELERY_RESULT_BACKEND = os.environ.get("CACHE_LOCATION")
CELERYD_TIME_LIMIT = os.environ.get("CELERYD_TIME_LIMIT", "3600")
CELERYD_MAX_TASKS_PER_CHILD = ""
CELERY_TASK_ROUTES = {
    "onadata.apps.api.tasks.publish_xlsform_async": {"queue": "publish_xlsform"},
    "onadata.apps.messaging.tasks.call_backend_async": {"queue": "post_processing"},
    "onadata.libs.utils.osm.save_osm_data_async": {"queue": "post_processing"},
    "onadata.apps.logger.tasks.update_xform_submission_count_async": {
        "queue": "post_processing"
    },
    "onadata.apps.logger.tasks.save_full_json_async": {"queue": "post_processing"},
    "onadata.apps.logger.tasks.update_project_date_modified_async": {
        "queue": "post_processing"
    },
    "onadata.libs.utils.csv_import.submit_csv_async": {"queue": "post_processing"},
    "onadata.apps.api.tasks.share_project_async": {"queue": "permissions_async"},
    "onadata.libs.utils.project_utils.propagate_project_permissions_async": {
        "queue": "permissions_async"
    },
    "onadata.libs.utils.project_utils.set_project_perms_to_xform_async": {
        "queue": "permissions_async"
    },
    "onadata.apps.logger.tasks.set_entity_list_perms_async": {
        "queue": "permissions_async"
    },
    "onadata.apps.viewer.tasks.create_xlsx_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_csv_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_kml_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_osm_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_zip_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_csv_zip_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_sav_zip_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_geojson_export": {"queue": "file_exports"},
    "onadata.apps.viewer.tasks.create_external_export": {"queue": "external_exports"},
    "onadata.apps.viewer.tasks.create_google_sheet_export": {
        "queue": "external_exports"
    },
    "google_export.tasks.call_google_sheet_service": {"queue": "external_exports"},
    "google_export.tasks.sync_update_google_sheets": {"queue": "external_exports"},
    "google_export.tasks.sync_delete_google_sheets": {"queue": "external_exports"},
    "google_export.tasks.initial_google_sheet_export": {"queue": "external_exports"},
    "onadata.apps.api.tasks.regenerate_form_instance_json": {
        "queue": "bulk_submissions_edit"
    },
    "onadata.apps.api.tasks.delete_xform_submissions_async": {
        "queue": "bulk_submissions_edit"
    },
    "onadata.apps.logger.tasks.decrypt_instance_async": {"queue": "decryption"},
    "onadata.apps.logger.tasks.adjust_xform_num_of_decrypted_submissions_async": {
        "queue": "post_processing"
    },
    "onadata.apps.logger.tasks.adjust_elist_num_entities_async": {
        "queue": "post_processing"
    },
}
CELERY_BEAT_SCHEDULE = {
    "Mark-Expired-Exports-Failed": {
        "task": "onadata.apps.viewer.tasks.mark_expired_pending_exports_as_failed",
        "schedule": crontab(hour="*", minute="0"),
        "options": {"ignore_result": True},
    },
    "Delete-Expired-Failed-Exports": {
        "task": "onadata.apps.viewer.tasks.delete_expired_failed_exports",
        "schedule": crontab(hour="*", minute="10"),
        "options": {"ignore_result": True},
    },
    "celery.backend_cleanup": {
        "task": "celery.backend_cleanup",
        "schedule": crontab(hour="*", minute="30"),
        "options": {"ignore_result": True},
    },
}
CELERY_TASK_RESULT_EXPIRES = 3600

# --------------------------------------------------------------------
# AWS Configs
# --------------------------------------------------------------------
AWS_ACCESS_KEY_ID = os.environ.get("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.environ.get("AWS_SECRET_ACCESS_KEY")
AWS_STORAGE_BUCKET_NAME = os.environ.get("AWS_STORAGE_BUCKET_NAME")
AWS_DEFAULT_ACL = os.environ.get("AWS_DEFAULT_ACL", "private")
AWS_S3_FILE_OVERWRITE = os.environ.get("AWS_S3_FILE_OVERWRITE") in true_vals
AWS_S3_SECURE_URLS = os.environ.get("AWS_S3_SECURE_URLS") in true_vals
AWS_S3_REGION_NAME = os.environ.get("AWS_S3_REGION_NAME")
AWS_S3_ENDPOINT_URL = os.environ.get("AWS_S3_ENDPOINT_URL")

# --------------------------------------------------------------------
# Mailing Configs
# --------------------------------------------------------------------
EMAIL_BACKEND = os.environ.get(
    "EMAIL_BACKEND", "django.core.mail.backends.smtp.EmailBackend"
)
EMAIL_HOST = os.environ.get("EMAIL_HOST", "")
EMAIL_PORT = os.environ.get("EMAIL_PORT", 587)
EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "")
EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "noreply+api@ona.io")
SERVER_EMAIL = DEFAULT_FROM_EMAIL
ENABLE_EMAIL_VERIFICATION = True
VERIFIED_KEY_TEXT = "ALREADY_ACTIVATED"
VERIFICATION_URL = str_to_dict(
    os.environ.get(
        "VERIFICATION_URL", f'{{"*": "{ZEBRA_URL}/email-verification-confirmation"}}'
    )
)
PROJECT_INVITATION_URL = str_to_dict(
    os.environ.get("PROJECT_INVITATION_URL", f'{{"*": "{ZEBRA_URL}/join"}}')
)
# --------------------------------------------------------------------
# Cross Origin Requests (CORS) Configs
# --------------------------------------------------------------------
CORS_ALLOWED_ORIGINS = [
    ZEBRA_URL,
    ENKETO_URL,
]
if os.environ.get("CORS_EXPOSE_HEADERS"):
    CORS_ALLOW_HEADERS = tuple(os.environ.get("CORS_ALLOW_HEADERS").split(" "))
else:
    CORS_EXPOSE_HEADERS = (
        "Content-Type",
        "Location",
        "WWW-Authenticate",
        "Content-Language",
        "ETag",
        "X-total",
    )
if os.environ.get("CORS_ALLOW_HEADERS"):
    CORS_ALLOWED_ORIGINS = tuple(os.environ.get("CORS_ALLOW_HEADERS").split(" "))
else:
    CORS_ALLOW_HEADERS = (
        "x-requested-with",
        "content-type",
        "accept",
        "origin",
        "authorization",
        "x-csrftoken",
        "x-csrf-token",
        "cache-control",
        "if-none-match",
    )
# --------------------------------------------------------------------
# Google Configs
# --------------------------------------------------------------------
GOOGLE_EXPORT = os.environ.get("ENABLE_GOOGLE_EXPORT") in true_vals
GOOGLE_SITE_VERIFICATION = os.environ.get("GOOGLE_SITE_VERIFICATION")
GOOGLE_ANALYTICS_PROPERTY_ID = os.environ.get("GOOGLE_ANALYTICS_PROPERTY_ID")
GOOGLE_ANALYTICS_DOMAIN = os.environ.get("GOOGLE_ANALYTICS_DOMAIN")
GOOGLE_STEP2_URI = ""
GOOGLE_OAUTH2_CLIENT_ID = os.environ.get("GOOGLE_OAUTH2_CLIENT_ID")
GOOGLE_OAUTH2_CLIENT_SECRET = os.environ.get("GOOGLE_OAUTH2_CLIENT_SECRET")
GOOGLE_PROJECT_ID = os.environ.get("GOOGLE_PROJECT_ID")  # new
GOOGLE_CLIENT_EMAIL = ""
if GOOGLE_EXPORT:
    GOOGLE_FLOW = {
        "web": {
            "client_id": GOOGLE_OAUTH2_CLIENT_ID,
            "project_id": GOOGLE_PROJECT_ID,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": GOOGLE_OAUTH2_CLIENT_SECRET,
        }
    }
    INSTALLED_APPS += ("google_export",)
    REST_SERVICES_TO_MODULES = {"google_sheets": "google_export.service"}
    REST_SERVICES_TO_SERIALIZERS = {
        "google_sheets": "google_export.serializer.GoogleSheetsSerializer"
    }
    CUSTOM_MAIN_URLS.add("google_export.urls")
# Google export retry constants
GOOGLE_EXPORT_RETRY_SECONDS_MIN = 120
GOOGLE_EXPORT_RETRY_SECONDS_MAX = 600

# --------------------------------------------------------------------
# Pricing Configs
# --------------------------------------------------------------------
ADDITIONAL_API_USAGE_PERCENTAGE = 10
MONTHLY_SUBMISSIONS_EXTRA = 50
MONTHLY_SUBMISSIONS_CACHE_TIMEOUT = 60 * 60 * 24
ZOHO_AUTH_TOKEN = os.environ.get("ZOHO_AUTH_TOKEN")
ZOHO_API_TOKEN = os.environ.get("ZOHO_API_TOKEN")
ZOHO_ORG_ID = ""
ZOHO_API_URL = "https://subscriptions.zoho.com/api/v1"
DEACTIVATE_ON_LIMIT_EXCEEDED = False
PRICING = os.environ.get("ENABLE_PRICING") in true_vals
PRICING_LIMIT_ENABLED = os.environ.get("PRICING_LIMIT_ENABLED") in true_vals
PRICING_API_LIMIT_ENABLED = os.environ.get("PRICING_API_LIMIT_ENABLED") in true_vals
PRICING_NO_ACCOUNT_BEHAVIOUR = os.environ.get(
    "PRICING_NO_ACCOUNT_BEHAVIOUR", "default"
)  # unlimited or default
PRICING_COUNT_API_CALLS = os.environ.get("PRICING_COUNT_API_CALLS") in true_vals
if PRICING:
    INSTALLED_APPS += ("pricing",)
    CUSTOM_MAIN_URLS.add("pricing.urls")
    PROFILE_SERIALIZER = "pricing.serializer.PersonalAccountSerializer"
    ORG_PROFILE_SERIALIZER = "pricing.serializer.OrganizationAccountSerializer"
    BASE_VIEWSET = "pricing.baseviewset.DefaultBaseViewset"
    ZOHO_OAUTH_REFRESH_TOKEN_URL = "https://accounts.zoho.com/oauth/v2/token"
    ZOHO_OAUTH_CLIENT_ID = os.environ.get("ZOHO_OAUTH_CLIENT_ID")
    ZOHO_OAUTH_CLIENT_SECRET = os.environ.get("ZOHO_OAUTH_CLIENT_SECRET")
    ZOHO_OAUTH_CALLBACK_URI = "http://localhost:3000/oauth2callback"
    ZOHO_OAUTH_REFRESH_TOKEN = os.environ.get("ZOHO_OAUTH_REFRESH_TOKEN")

# --------------------------------------------------------------------
# Tableau Connector Configs
# --------------------------------------------------------------------
ENABLE_TABLEAU_CONNECTOR = os.environ.get("ENABLE_TABLEAU_CONNECTOR") in true_vals
if ENABLE_TABLEAU_CONNECTOR:
    INSTALLED_APPS += ("connector",)
    CUSTOM_MAIN_URLS.add("connector.urls")

# --------------------------------------------------------------------
# Logging Configs
# --------------------------------------------------------------------
if os.environ.get("SENTRY_DSN"):
    sentry_sdk.init(
        dsn=os.environ.get("SENTRY_DSN"),
        integrations=[DjangoIntegration(), CeleryIntegration()],
        send_default_pii=False,
        environment=os.environ.get("ENVIRONMENT", "production"),
        release=os.environ.get(
            "RELEASE_TAG",
        ),
    )
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "%(levelname)s %(asctime)s %(module)s"
            + " %(process)d %(thread)d %(message)s"
        },
        "simple": {"format": "%(levelname)s %(message)s"},
        "profiler": {"format": "%(levelname)s %(asctime)s %(message)s"},
        "sql": {
            "format": "%(levelname)s %(process)d %(thread)d"
            + " %(time)s seconds %(message)s %(sql)s"
        },
        "sql_totals": {
            "format": "%(levelname)s %(process)d %(thread)d %(time)s seconds"
            + " %(message)s %(num_queries)s sql queries"
        },
    },
    "filters": {
        "require_debug_false": {"()": "django.utils.log.RequireDebugFalse"},
        # Define filter for suspicious urls
        "skip_suspicious_operations": {
            "()": "django.utils.log.CallbackFilter",
            "callback": skip_suspicious_operations,
        },
    },
    "handlers": {
        "mail_admins": {
            "level": "ERROR",
            "filters": ["require_debug_false", "skip_suspicious_operations"],
            "class": "django.utils.log.AdminEmailHandler",
            "email_backend": "django.core.mail.backends.dummy.EmailBackend",
        },
        "console": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "verbose",
            "stream": sys.stdout,
        },
        "audit": {
            "level": "DEBUG",
            "class": "onadata.libs.utils.log.AuditLogHandler",
            "formatter": "verbose",
            "model": "onadata.apps.main.models.audit.AuditLog",
        },
    },
    "loggers": {
        "django.request": {
            "handlers": ["console"],
            "level": "DEBUG",
            "propagate": True,
        },
        "console_logger": {
            "handlers": ["console"],
            "level": "DEBUG",
            "propagate": True,
        },
        "audit_logger": {"handlers": ["audit"], "level": "DEBUG", "propagate": True},
    },
}

CSP_IMG_SRC += [
    "'self'",
    "data:",
    HOST_URL,
    f"https://{AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com",
]
CSP_FRAME_ANCESTORS += [
    "'self'",
    HOST_URL,
]
CSP_SCRIPT_SRC += [HOST_URL]
CSP_STYLE_SRC += [
    HOST_URL,
    "'sha256-G3Xm3ZS21FJH+2uN2TQz2S2fm1GRbOTSg2Qr3MisSEg='",
    "'sha256-71Gb4W6A/s78onLpjMXIIFjXMB7YFIRd5Z1NKJ+UwHY='",
    "'sha256-52i34Zg+qg4/kTYjnNHEmW8jhzGRxjt77FX9aveiXqw='",
]
CSP_FRAME_SRC += [HOST_URL]
CSP_FONT_SRC += [HOST_URL]
CSP_CONNECT_SRC += [HOST_URL]
MIDDLEWARE = ("csp.middleware.CSPMiddleware",) + MIDDLEWARE


CSRF_COOKIE_SECURE = os.environ.get("CSRF_COOKIE_SECURE", "True") in true_vals
CSRF_COOKIE_SAMESITE = os.environ.get("CSRF_COOKIE_SAMESITE", "Strict")
CSRF_COOKIE_SECURE = os.environ.get("CSRF_COOKIE_SECURE", "True") in true_vals
CSRF_USE_SESSIONS = os.environ.get("CSRF_USE_SESSIONS", "True") in true_vals
SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "True") in true_vals
SESSION_COOKIE_SAMESITE = os.environ.get("SESSION_COOKIE_SAMESITE", "Strict")

SUBMISSION_RETRIEVAL_THRESHOLD = int(
    os.environ.get("SUBMISSION_RETRIEVAL_THRESHOLD", 100000)
)

STANDARD_PAGINATION_MAX_PAGE_SIZE = int(
    os.environ.get("STANDARD_PAGINATION_MAX_PAGE_SIZE", 1000)
)

CSV_FILESIZE_IMPORT_ASYNC_THRESHOLD = int(
    os.environ.get("CSV_FILESIZE_IMPORT_ASYNC_THRESHOLD", 0)
)
ONA_SITE_PROTOCOL = os.environ.get("ONA_SITE_PROTOCOL", "https")
ADMIN_URL_PATH = os.environ.get("ADMIN_URL_PATH", "Internapalooza")
RESERVED_USERNAMES += [os.environ.get("ADMIN_URL_PATH", "Internapalooza")]

import os
import json
from celery.schedules import crontab
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration
from sentry_sdk.integrations.celery import CeleryIntegration
from onadata.settings.common import *  # noqa
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

true_vals = ['True', 'true']

REGISTRATION_OPEN = os.environ.get('REGISTRATION_OPEN') in true_vals
# --------------------------------------------------------------------
# Host Configs
# --------------------------------------------------------------------

HOST_URL = os.environ.get('HOST_URL')

# --------------------------------------------------------------------
# Database Configs
# --------------------------------------------------------------------

def str_to_dict(val):
    try:
        return json.loads(val)
    except (TypeError, ValueError):
        return val

DATABASES = {
    'default': {
        'ENGINE': os.environ.get('DB_ENGINE', 'django.contrib.gis.db.backends.postgis'),
        'NAME': os.environ.get('MAIN_DB_NAME'),
        'USER': os.environ.get('DB_USER'),
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': os.environ.get('DB_HOST'),
        'PORT': os.environ.get('DB_PORT'),
        'DISABLE_SERVER_SIDE_CURSORS': os.environ.get('DB_DISABLE_SERVER_SIDE_CURSORS')
    },
    'replica1': {
        'ENGINE': os.environ.get('DB_ENGINE', 'django.contrib.gis.db.backends.postgis'),
        'NAME': os.environ.get('REPLICA_ONE_DB_NAME'),
        'USER': os.environ.get('DB_USER'),
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': os.environ.get('DB_HOST'),
        'PORT': os.environ.get('DB_PORT'),
        'DISABLE_SERVER_SIDE_CURSORS': os.environ.get('DB_DISABLE_SERVER_SIDE_CURSORS')
    },
    'replica2': {
        'ENGINE': os.environ.get('DB_ENGINE', 'django.contrib.gis.db.backends.postgis'),
        'NAME': os.environ.get('REPLICA_TWO_DB_NAME'),
        'USER': os.environ.get('DB_USER'),
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': os.environ.get('DB_HOST'),
        'PORT': os.environ.get('DB_PORT'),
        'DISABLE_SERVER_SIDE_CURSORS': os.environ.get('DB_DISABLE_SERVER_SIDE_CURSORS')
    }
}
SLAVE_DATABASES = ['replica1', 'replica2']
DATABASE_ROUTERS = ['multidb.PinningMasterSlaveRouter']
MULTIDB_PINNING_SECONDS = os.environ.get('MULTIDB_PINNING_SECONDS', 10)
# --------------------------------------------------------------------
# Cache Configs
# --------------------------------------------------------------------
CACHES = {
    'default': {
        'BACKEND': os.environ.get('CACHE_BACKEND'),
        'LOCATION': os.environ.get('CACHE_LOCATION'),
        'OPTIONS': {
        'CLIENT_CLASS': os.environ.get('CACHE_CLIENT_CLASS')
        },
        'KEY_PREFIX': 'onadata'
    }
}
# --------------------------------------------------------------------
# OpenID Connect Configurations
# --------------------------------------------------------------------
OPENID_CONNECT_AUTH_SERVERS = { # needs review
    'wfp': {
        'AUTHORIZATION_ENDPOINT': os.environ.get('OPENID_AUTHORIZATION_ENDPOINT', 'https://ciam.auth.wfp.org/oauth2/authorize'),
        'CLIENT_ID': os.environ.get('OPENID_CLIENT_ID'),
        'CLIENT_SECRET': os.environ.get('OPENID_CLIENT_SECRET'),
        'JWKS_ENDPOINT': 'https://ciam.auth.wfp.org/oauth2/jwks',
        'TOKEN_ENDPOINT': 'https://ciam.auth.wfp.org/oauth2/token',
        'REDIRECT_URI': 'https://api.moda.wfp.org/oidc/wfp/callback',
        'END_SESSION_ENDPOINT': 'https://ciam.auth.wfp.org/oidc/logout',
        'SCOPE': 'openid',
        'RESPONSE_TYPE': 'code',
        'RESPONSE_MODE': '',
        'USE_NONCES': True,
    }
}

OPENID_CONNECT_VIEWSET_CONFIG = { # needs review
    'REDIRECT_AFTER_AUTH': 'https://moda.wfp.org/authenticate',
    'USE_SSO_COOKIE': True,
    'USE_AUTH_BACKEND': False,
    'AUTH_BACKEND': None,
    'USE_RAPIDPRO_VIEWSET': False,
    'JWT_SECRET_KEY': os.environ.get('JWT_SECRET_KEY'),
    'JWT_ALGORITHM': 'HS256',
    'SSO_COOKIE_DOMAIN': '.moda.wfp.org',
    'MAP_CLAIM_TO_MODEL': {
        'given_name': 'first_name',
        'family_name': 'last_name',
        'preferred_username': 'username',
        'sub': 'email',
    }
}
# --------------------------------------------------------------------
# USER Creation via API
# --------------------------------------------------------------------
DISABLE_CREATING_USERS = os.environ.get('DISABLE_CREATING_USERS')

# --------------------------------------------------------------------
# General Configs
# --------------------------------------------------------------------
REST_FRAMEWORK = {
    # Use hyperlinked styles by default.
    # Only used if the `serializer_class` attribute is not set on a view.
    'DEFAULT_MODEL_SERIALIZER_CLASS': 'rest_framework.serializers.HyperlinkedModelSerializer',
    # Use Django's standard `django.contrib.auth` permissions,
    # or allow read-only access for unauthenticated users.
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
        'rest_framework.permissions.DjangoModelPermissions'
    ),
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'onadata.libs.authentication.DigestAuthentication',
        'onadata.libs.authentication.SSOHeaderAuthentication',
        'onadata.libs.authentication.TempTokenAuthentication',
        'onadata.libs.authentication.EnketoTokenAuthentication',
        'oauth2_provider.contrib.rest_framework.OAuth2Authentication',
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
        'rest_framework.authentication.BasicAuthentication',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
        'rest_framework_jsonp.renderers.JSONPRenderer',
        'rest_framework.renderers.BrowsableAPIRenderer',
        'rest_framework_csv.renderers.CSVRenderer',
    ),
}
MIDDLEWARE = (
'multidb.middleware.PinningRouterMiddleware',
'django.middleware.http.ConditionalGetMiddleware',
'corsheaders.middleware.CorsMiddleware',
'django.middleware.common.CommonMiddleware',
'django.contrib.sessions.middleware.SessionMiddleware',
'onadata.libs.utils.middleware.LocaleMiddlewareWithTweaks',
'django.middleware.csrf.CsrfViewMiddleware',
'django.contrib.auth.middleware.AuthenticationMiddleware',
'django.contrib.messages.middleware.MessageMiddleware',
'onadata.libs.utils.middleware.HTTPResponseNotAllowedMiddleware',
'onadata.libs.utils.middleware.OperationalErrorMiddleware',
'django.middleware.clickjacking.XFrameOptionsMiddleware',
)
SECRET_KEY = os.environ.get('SECRET_KEY')
JWT_ALGORITHM = 'HS256'
JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY')
DEFAULT_FILE_STORAGE = os.environ.get('DEFAULT_FILE_STORAGE', 'storages.backends.s3boto3.S3Boto3Storage')
FORM_RENDERER = 'django.forms.renderers.TemplatesSetting'
OAUTH2_PROVIDER_APPLICATION_MODEL = "oauth2_provider.Application"
OAUTH2_PROVIDER['PKCE_REQUIRED'] = False
OAUTH2_PROVIDER['AUTHORIZATION_CODE_EXPIRE_SECONDS'] = 600
ALLOWED_HOSTS = ['*']
# ADMINS = ()
CUSTOM_MAIN_URLS = set()
EXPORT_TASK_PROGRESS_UPDATE_BATCH = 100
ZIP_EXPORT_COUNTDOWN = 3600  # 43200 seconds by default
# Time zone settings
TIME_ZONE = 'UTC'
# Time in minutes to lock out user from account
LOCKOUT_TIME = 30 * 60
MAX_LOGIN_ATTEMPTS = 10
# Set Cache-Control: max-age=30 seconds
CACHE_MIXIN_SECONDS = 30
INSTALLED_APPS += (
    'django.forms',
)
X_FRAME_OPTIONS = 'SAMEORIGIN'
# mainly for data submission attachments, the max size we can accept
DEFAULT_CONTENT_LENGTH = int(os.environ.get('DEFAULT_CONTENT_LENGTH'))
EXTRA_COLUMNS = ['_xform_id']
SUPPORT_EMAIL = os.environ.get('SUPPORT_EMAIL', "support@ona.io")
SUPPORTED_MEDIA_UPLOAD_TYPES = [
    'audio/mp3',
    'audio/mpeg',
    'audio/wav',
    'audio/x-m4a',
    'image/jpeg',
    'image/png',
    'image/svg+xml',
    'text/csv',
    'text/json',
    'video/3gpp',
    'video/mp4',
    'application/json',
    'application/geo+json',
    'application/pdf',
    'application/msword',
    'application/vnd.ms-excel',
    'application/vnd.ms-powerpoint',
    'application/vnd.oasis.opendocument.text',
    'application/vnd.oasis.opendocument.spreadsheet',
    'application/vnd.oasis.opendocument.presentation',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/zip',
]

# ------------------------------------------------------------------
# File System Storage
# ------------------------------------------------------------------

if DEFAULT_FILE_STORAGE == 'django.core.files.storage.FileSystemStorage':
    MEDIA_URL = os.environ.get('MEDIA_URL')
    MEDIA_ROOT = os.environ.get('MEDIA_ROOT', os.path.join('/', 'srv', 'onadata', 'media/'))

USE_CUSTOM_TEMPLATE = os.environ.get('USE_CUSTOM_TEMPLATE') in true_vals
if USE_CUSTOM_TEMPLATE:
    CUSTOM_TEMPLATE_DIR = os.environ.get('CUSTOM_TEMPLATE_DIR')
    if isinstance(CUSTOM_TEMPLATE_DIR, str):
        # site templates overrides
        TEMPLATES[0]['DIRS'] = [
            os.path.join(CUSTOM_TEMPLATE_DIR, 'templates'),
        ] + TEMPLATES[0]['DIRS']
        # site static files path
        STATICFILES_DIRS += (os.path.join(CUSTOM_TEMPLATE_DIR, 'static'), )

# ------------------------------------------------------------------
# Flags
# ------------------------------------------------------------------
SITE_READ_ONLY = os.environ.get('SITE_READ_ONLY') in ['True', 'true']
DEBUG = os.environ.get('DEBUG') in true_vals
TESTING_MODE = os.environ.get('TESTING_MODE') in true_vals
APPS_DIR = os.environ.get('APPS_DIR') in true_vals
TAGGIT_CASE_INSENSITIVE = os.environ.get('TAGGIT_CASE_INSENSITIVE') in true_vals
STREAM_DATA = os.environ.get('STREAM_DATA', 'True')  in true_vals
VERIFY_SSL = os.environ.get('VERIFY_SSL') in true_vals
REQUIRE_ODK_AUTHENTICATION = os.environ.get('REQUIRE_ODK_AUTHENTICATION') in true_vals
MESSAGING_ASYNC_NOTIFICATION = os.environ.get('MESSAGING_ASYNC_NOTIFICATION') in true_vals
ALLOW_PUBLIC_DATASETS = os.environ.get('ALLOW_PUBLIC_DATASETS') in true_vals
ASYNC_POST_SUBMISSION_PROCESSING_ENABLED = os.environ.get('ASYNC_POST_SUBMISSION_PROCESSING_ENABLED') in true_vals
ORG_ON_CREATE_IS_ACTIVE = os.environ.get('ORG_ON_CREATE_IS_ACTIVE') in true_vals
TEMPLATES[0]['OPTIONS']['debug'] = os.environ.get('DEBUG') in true_vals

# --------------------------------------------------------------------
# ODK Key Configs
# --------------------------------------------------------------------
ODK_TOKEN_FERNET_KEY = os.environ.get('ODK_TOKEN_FERNET_KEY') # Needs review
ODK_KEY_LIFETIME = os.environ.get('ODK_TOKEN_LIFETIME', 365)
ODK_TOKEN_LENGTH = os.environ.get('ODK_TOKEN_LENGTH', 7)

# --------------------------------------------------------------------
# External Service(s) Configs
# --------------------------------------------------------------------
KPI_FORMBUILDER_URL = os.environ.get('KPI_FORMBUILDER_URL')
KPI_INTERNAL_SERVICE_URL = os.environ.get('KPI_INTERNAL_URL')

ZEBRA_URL = os.environ.get('ZEBRA_URL')
ENKETO_API_SALT = os.environ.get('ENKETO_API_SALT')
ENKETO_API_TOKEN = os.environ.get('ENKETO_API_TOKEN')
ENKETO_AUTH_COOKIE_DOMAIN = os.environ.get('ENKETO_AUTH_COOKIE_DOMAIN')
ENKETO_CLIENT_LOGIN_URL = str_to_dict(os.environ.get('ENKETO_CLIENT_LOGIN_URL', f'{{"*": "{ZEBRA_URL}/login"}}'))
ENKETO_URL = os.environ.get('ENKETO_URL')
ENKETO_API_SURVEY_PATH = '/api_v2/survey'
ENKETO_PREVIEW_URL = urljoin(ENKETO_URL, ENKETO_API_SURVEY_PATH + '/preview')
ENKETO_API_INSTANCE_IFRAME_URL = ENKETO_URL + 'api_v1/instance/iframe'
ENKETO_API_INSTANCE_IFRAME_URL = urljoin(ENKETO_URL, 'api_v2/instance/iframe')
ENKETO_API_SURVEY_PATH = '/api_v2/survey'
ENKETO_API_INSTANCE_PATH = '/api_v2/instance'
ENKETO_PREVIEW_URL = urljoin(ENKETO_URL, ENKETO_API_SURVEY_PATH + '/preview')
ENKETO_API_SURVEY_PATH = urljoin(ENKETO_URL,
                                ENKETO_API_SURVEY_PATH + '/offline')
ENKETO_AUTH_COOKIE = '__enketo'
ENKETO_META_UID_COOKIE = '__enketo_meta_uid'

# --------------------------------------------------------------------
# Celery Configs
# --------------------------------------------------------------------
BROKER_URL = os.environ.get('CELERY_BROKER_URL')
CELERY_WORKER_SEND_TASK_EVENTS = True
CELERY_TASK_SEND_SENT_EVENT = True
CELERY_BROKER_URL = BROKER_URL
CELERY_RESULT_BACKEND = os.environ.get('CACHE_LOCATION')
CELERYD_TIME_LIMIT = '3600'
CELERYD_MAX_TASKS_PER_CHILD = ''
CELERY_TASK_ROUTES = {
    'onadata.apps.api.tasks.publish_xlsform_async': {
        'queue': 'publish_xlsform'
    },
    'onadata.apps.viewer.tasks.create_xlsx_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_csv_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_kml_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_osm_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_zip_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_csv_zip_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_sav_zip_export': {
        'queue': 'file_exports'
    },
    'onadata.apps.viewer.tasks.create_external_export': {
        'queue': 'external_exports'
    },
    'onadata.apps.viewer.tasks.create_google_sheet_export': {
        'queue': 'external_exports'
    },
    'google_export.tasks.call_google_sheet_service': {
        'queue': 'external_exports'
    },
    'google_export.tasks.sync_update_google_sheets': {
        'queue': 'external_exports'
    },
    'google_export.tasks.sync_delete_google_sheets': {
        'queue': 'external_exports'
    },
    'onadata.apps.messaging.tasks.call_backend_async': {
        'queue': 'messaging'
    },
    'onadata.apps.messaging.tasks.call_backend_async': {
          'queue': 'post_processing'
    },
    'onadata.libs.utils.osm.save_osm_data_async': {
        'queue': 'post_processing'
    },
    'onadata.apps.logger.models.instance.update_xform_submission_count_async': {
        'queue': 'post_processing'
    },
    'onadata.apps.logger.models.instance.save_full_json_async': {
        'queue': 'post_processing'
    },
    'onadata.apps.logger.models.instance.update_project_date_modified_async': {
        'queue': 'post_processing'
    },

}
CELERY_BEAT_SCHEDULE = {
    'Mark-Expired-Exports-Failed': {
        'task':
        'onadata.apps.viewer.tasks.mark_expired_pending_exports_as_failed',
        'schedule': crontab(hour='*', minute='0'),
        'options': {
            'ignore_result': True
        }
    },
    'Delete-Expired-Failed-Exports': {
        'task': 'onadata.apps.viewer.tasks.delete_expired_failed_exports',
        'schedule': crontab(hour='*', minute='10'),
        'options': {
            'ignore_result': True
        }
    },
    'celery.backend_cleanup': {
        'task': 'celery.backend_cleanup',
        'schedule': crontab(hour='*', minute='30'),
        'options': {
            'ignore_result': True
        }
    },
    'Delete-Inactive-Users': {
        'task': 'onadata.apps.api.tasks.delete_user_async',
        'schedule': crontab(0, 0, day_of_month='1'),
        'options': {
            'ignore_result': True
        }
    },
}
CELERY_TASK_RESULT_EXPIRES = 3600

# --------------------------------------------------------------------
# AWS Configs
# --------------------------------------------------------------------
AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
AWS_STORAGE_BUCKET_NAME = os.environ.get('AWS_STORAGE_BUCKET_NAME')
AWS_DEFAULT_ACL = os.environ.get('AWS_DEFAULT_ACL', 'private')
AWS_S3_FILE_OVERWRITE = os.environ.get('AWS_S3_FILE_OVERWRITE') in true_vals
AWS_S3_SECURE_URLS = os.environ.get('AWS_S3_SECURE_URLS') in true_vals
AWS_S3_REGION_NAME = os.environ.get('AWS_S3_REGION_NAME')
AWS_S3_ENDPOINT_URL = os.environ.get('AWS_S3_ENDPOINT_URL')

# --------------------------------------------------------------------
# Mailing Configs
# --------------------------------------------------------------------
EMAIL_BACKEND = os.environ.get('EMAIL_BACKEND', 'django.core.mail.backends.smtp.EmailBackend')
EMAIL_HOST = os.environ.get('EMAIL_HOST', '')
EMAIL_PORT = os.environ.get('EMAIL_PORT', 587)
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'noreply+api@ona.io')
SERVER_EMAIL = DEFAULT_FROM_EMAIL
ENABLE_EMAIL_VERIFICATION = True
VERIFIED_KEY_TEXT = 'ALREADY_ACTIVATED'
VERIFICATION_URL = str_to_dict(os.environ.get('VERIFICATION_URL', f'{{"*": "{ZEBRA_URL}/email-verification-confirmation"}}'))
PROJECT_INVITATION_URL = str_to_dict(os.environ.get('PROJECT_INVITATION_URL', f'{{"*": "{ZEBRA_URL}/join"}}'))
# --------------------------------------------------------------------
# Cross Origin Requests (CORS) Configs
# --------------------------------------------------------------------
CORS_ALLOWED_ORIGINS = [
    ZEBRA_URL,
    ENKETO_URL,
]
CORS_EXPOSE_HEADERS = ('Content-Type', 'Location', 'WWW-Authenticate',
                    'Content-Language', 'ETag', 'X-total')
CORS_ALLOW_HEADERS = ('x-requested-with', 'content-type', 'accept', 'origin',
                    'authorization', 'x-csrftoken', 'x-csrf-token',
                    'cache-control', 'if-none-match')
# --------------------------------------------------------------------
# Google Configs
# --------------------------------------------------------------------
GOOGLE_EXPORT = os.environ.get('ENABLE_GOOGLE_EXPORT') in true_vals
GOOGLE_SITE_VERIFICATION = os.environ.get('GOOGLE_SITE_VERIFICATION')
GOOGLE_ANALYTICS_PROPERTY_ID = os.environ.get('GOOGLE_ANALYTICS_PROPERTY_ID')
GOOGLE_ANALYTICS_DOMAIN = os.environ.get('GOOGLE_ANALYTICS_DOMAIN')
GOOGLE_STEP2_URI = ''
GOOGLE_OAUTH2_CLIENT_ID = os.environ.get("GOOGLE_OAUTH2_CLIENT_ID")
GOOGLE_OAUTH2_CLIENT_SECRET = os.environ.get("GOOGLE_OAUTH2_CLIENT_SECRET")
GOOGLE_PROJECT_ID = os.environ.get("GOOGLE_PROJECT_ID") # new
GOOGLE_CLIENT_EMAIL = ''
if GOOGLE_EXPORT:
    GOOGLE_FLOW = {
        "web": {
            "client_id": GOOGLE_OAUTH2_CLIENT_ID,
            "project_id": GOOGLE_PROJECT_ID,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": GOOGLE_OAUTH2_CLIENT_SECRET
        }
    }
    INSTALLED_APPS += ("google_export", )
    REST_SERVICES_TO_MODULES = {'google_sheets': 'google_export.service'}
    REST_SERVICES_TO_SERIALIZERS = {
        'google_sheets': 'google_export.serializer.GoogleSheetsSerializer'
    }
    CUSTOM_MAIN_URLS.add('google_export.urls')
# Google export retry constants
GOOGLE_EXPORT_RETRY_SECONDS_MIN = 120
GOOGLE_EXPORT_RETRY_SECONDS_MAX = 600
# --------------------------------------------------------------------
# Pricing Configs
# --------------------------------------------------------------------
ADDITIONAL_API_USAGE_PERCENTAGE = 10
MONTHLY_SUBMISSIONS_EXTRA = 50
MONTHLY_SUBMISSIONS_CACHE_TIMEOUT = 60 * 60 * 24
ZOHO_AUTH_TOKEN = os.environ.get("ZOHO_AUTH_TOKEN")
ZOHO_API_TOKEN = os.environ.get("ZOHO_API_TOKEN")
ZOHO_ORG_ID = ""
ZOHO_API_URL = "https://subscriptions.zoho.com/api/v1"
DEACTIVATE_ON_LIMIT_EXCEEDED = False
PRICING = os.environ.get('ENABLE_PRICING') in true_vals
PRICING_LIMIT_ENABLED = os.environ.get('PRICING_LIMIT_ENABLED') in true_vals
PRICING_API_LIMIT_ENABLED = os.environ.get('PRICING_API_LIMIT_ENABLED') in true_vals
PRICING_NO_ACCOUNT_BEHAVIOUR = os.environ.get('PRICING_NO_ACCOUNT_BEHAVIOUR', "default")  # unlimited or default
PRICING_COUNT_API_CALLS = os.environ.get('PRICING_COUNT_API_CALLS') in true_vals
if PRICING:
    INSTALLED_APPS += ("pricing", )
    CUSTOM_MAIN_URLS.add('pricing.urls')
    PROFILE_SERIALIZER = "pricing.serializer.PersonalAccountSerializer"
    ORG_PROFILE_SERIALIZER = "pricing.serializer.OrganizationAccountSerializer"
    BASE_VIEWSET = "pricing.baseviewset.DefaultBaseViewset"
    ZOHO_OAUTH_REFRESH_TOKEN_URL = "https://accounts.zoho.com/oauth/v2/token"
    ZOHO_OAUTH_CLIENT_ID = os.environ.get('ZOHO_OAUTH_CLIENT_ID')
    ZOHO_OAUTH_CLIENT_SECRET = os.environ.get('ZOHO_OAUTH_CLIENT_SECRET')
    ZOHO_OAUTH_CALLBACK_URI = "http://localhost:3000/oauth2callback"
    ZOHO_OAUTH_REFRESH_TOKEN = os.environ.get('ZOHO_OAUTH_REFRESH_TOKEN')
# --------------------------------------------------------------------
# Tableau Connector Configs
# --------------------------------------------------------------------
ENABLE_TABLEAU_CONNECTOR = os.environ.get("ENABLE_TABLEAU_CONNECTOR") in true_vals
if ENABLE_TABLEAU_CONNECTOR:
    INSTALLED_APPS += ("connector", )
    CUSTOM_MAIN_URLS.add('connector.urls')
# --------------------------------------------------------------------
# Logging Configs
# --------------------------------------------------------------------
sentry_sdk.init(
    dsn=os.environ.get('SENTRY_DSN'),
    integrations=[DjangoIntegration(), CeleryIntegration()],
    # If you wish to associate users to errors (assuming you are using
    # django.contrib.auth) you may enable sending PII data.
    send_default_pii=False,
    # By default the SDK will try to use the SENTRY_RELEASE
    # environment variable, or infer a git commit
    # SHA as release, however you may want to set
    # something more human-readable.
    # release="myapp@1.0.0",
    release=os.environ.get('RELEASE_TAG', ),
)
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format':
            '%(levelname)s %(asctime)s %(module)s' +
            ' %(process)d %(thread)d %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
        'profiler': {
            'format': '%(levelname)s %(asctime)s %(message)s'
        },
        'sql': {
            'format':
            '%(levelname)s %(process)d %(thread)d' +
            ' %(time)s seconds %(message)s %(sql)s'
        },
        'sql_totals': {
            'format':
            '%(levelname)s %(process)d %(thread)d %(time)s seconds' +
            ' %(message)s %(num_queries)s sql queries'
        }
    },
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        },
        # Define filter for suspicious urls
        'skip_suspicious_operations': {
            '()': 'django.utils.log.CallbackFilter',
            'callback': skip_suspicious_operations,
        },
    },
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false', 'skip_suspicious_operations'],
            'class': 'django.utils.log.AdminEmailHandler',
            'email_backend': 'django.core.mail.backends.dummy.EmailBackend'
        },
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'verbose',
            'stream': sys.stdout
        },
        'audit': {
            'level': 'DEBUG',
            'class': 'onadata.libs.utils.log.AuditLogHandler',
            'formatter': 'verbose',
            'model': 'onadata.apps.main.models.audit.AuditLog'
        },
    },
    'loggers': {
        'django.request': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
        },
        'console_logger': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True
        },
        'audit_logger': {
            'handlers': ['audit'],
            'level': 'DEBUG',
            'propagate': True
        },
    }
}
try:
    CSP_IMG_SRC += [
        "'self'",
        'data:',
        HOST_URL,
        f"https://{ AWS_STORAGE_BUCKET_NAME }.s3.amazonaws.com",
    ]
    CSP_FRAME_ANCESTORS += [
    "'self'",
    HOST_URL,
    ]
    CSP_SCRIPT_SRC += [HOST_URL]
    CSP_STYLE_SRC += [
        HOST_URL,
        "'sha256-G3Xm3ZS21FJH+2uN2TQz2S2fm1GRbOTSg2Qr3MisSEg='",
        "'sha256-71Gb4W6A/s78onLpjMXIIFjXMB7YFIRd5Z1NKJ+UwHY='",
        "'sha256-52i34Zg+qg4/kTYjnNHEmW8jhzGRxjt77FX9aveiXqw='",
    ]
    CSP_FRAME_SRC += [HOST_URL]
    CSP_FONT_SRC += [HOST_URL]
    CSP_CONNECT_SRC += [HOST_URL]
    MIDDLEWARE = ('csp.middleware.CSPMiddleware',) + MIDDLEWARE
except NameError:
    # may be running a version of onadata that has yet to get the csp-django headers integrated.
    pass
CSRF_COOKIE_SECURE = True
CSRF_COOKIE_SAMESITE = 'Strict'
CSRF_COOKIE_SECURE = True
CSRF_USE_SESSIONS = True
SESSION_COOKIE_SECURE = True
SESSION_COOKIE_SAMESITE = 'Strict'

SUBMISSION_RETRIEVAL_THRESHOLD = 100000
STANDARD_PAGINATION_MAX_PAGE_SIZE = os.environ.get("STANDARD_PAGINATION_MAX_PAGE_SIZE", 1000)

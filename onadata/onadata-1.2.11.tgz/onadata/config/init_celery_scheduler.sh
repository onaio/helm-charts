celery -A onadata.celeryapp \
    --workdir=/srv/onadata \
    beat \
    --schedule=/srv/onadata/celerybeat-schedule \
    --loglevel=WARNING \
    --pidfile=/srv/onadata/celerybeat.pid

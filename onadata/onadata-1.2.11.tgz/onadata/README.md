# Ona Data Helm Chart

Ona Data is a data collection platform for XLSForm compliant forms.

The chart contains four deployments:

## Ona Data API

The Ona Data API is mostly responsible for handling all the requests made to the [Ona Data API](https://github.com/onaio/onadata).

It consists of either 1 - 2 containers per pod depending on whether the nginx sidecar has been enabled:

- onadata-api: The main OnaData service
- onadata-api-nginx-sidecar: The Nginx proxy used to serve static files and route requests to the Ona Data container.

## Ona Data Submissions API

The Ona Data submission API is mainly responsible for handling the creation of submissions and any other Aggregate api requests (/formList, /submissionList, e.t.c)

It consists of either 1 - 2 containers per pod depending on whether the nginx sidecar has been enabled:

- onadata-submissions-api: The main OnaData service
- onadata-submissions-api-nginx-sidecar: The Nginx proxy used to serve static files and route requests to the Ona Data container.

## Ona Data Scheduler

The Ona Data scheduler deployment mainly deploys a Celery scheduler for periodic task scheduling

It consists of only one container named "onadata-scheduler"

## Ona Data Worker

The Ona Data worker deployment mainly deploys a Celery worked for asynchronous task processing i.e Imports, Exports, Submission post processing e.t.c

It consists of only one container named "onadata-worker"

# Onadata Local settings

The onadata local_settings.py loads configs from the environment. These environment variables are set by either loading them from the configmap or secrets. you can set these by adding values in `onadata.localSettings` or `confisSecrets`.


## FAQ

Q: How do I view logs on Ona Data ?

A: Logs for the deployment can be viewed in two ways depending on how the chart is deployed

  - If the chart is deployed with the Nginx sidecar enabled, the logs can be viewed via:

      ```sh
      kubectl logs pod/<pod-name> <container-name i.e onadata-api,onadata-ap-nginx-sidecar>
      ```

  - If the chart is deployed without the Nginx sidecar, the logs can be viewed via:

      ```sh
      kubectl logs pod/<pod-name>
      ```

Q: How can one execute commands within the containers when the nginx sidecar is enabled ?

A: Commands can be executed in specific containers via the `kubectl exec` command. i.e

  ```sh
  kubectl exec -it pod/<pod-name> -c onadata-api -- /bin/bash  # Starts a bash terminal on the Ona Data container
  ```

Q: How do I view the current process activity of uWSGI ?

A: The OnaData deployment comes with `uwsgitop` installed by default; Maintainers can run the command below within one of the uwsgi containers in order to view the current resource utilization and status of the uwsgi process

```sh
kubectl exec -it pod/<pod-name> -c onadata-api -- /bin/bash
$ uwsgitop :8001
```

# publishing to the charts index
```console
cd helm-charts/onadata
helm package ~/src/ona/infrastructure/helm/charts/onadata # path to the helm chart locally
helm repo index --url https://raw.githubusercontent.com/onaio/helm-charts/gh-pages/ . # run from root of repo
```
```
```

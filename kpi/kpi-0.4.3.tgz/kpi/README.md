### KPI Helm chart

- Helm cart for deploying https://github.com/onaio/kpi

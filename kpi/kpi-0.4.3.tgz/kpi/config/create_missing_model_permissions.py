from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from kpi.models import Asset

permissions_manager = Permission.objects
content_type_manager = ContentType.objects
asset_content_type = content_type_manager.get_for_model(Asset)
content_types = [asset_content_type]
permissions_manager.filter(content_type__in=content_types)

asset_permissions = Permission.objects.filter(content_type=asset_content_type)

asset_permission_strings = [
    ("Can add asset", "add_asset"),
    ("Can submit data to asset", "add_submissions"),
    ("Can modify submitted data for asset", "change_submissions"),
    ("Can delete asset", "delete_asset"),
    ("Can discover asset in public lists", "discover_asset"),
    ("Can manage all aspects of asset", "manage_asset"),
    (
        "Can make partial actions on submitted data for asset for specific users",
        "partial_submissions",
    ),
    ("Can change asset's sharing settings", "share_asset"),
    ("Can change sharing settings for asset's submitted data", "share_submissions"),
    ("Can validate submitted data asset", "validate_submissions"),
    ("Can view asset", "view_asset"),
    ("Can view submitted data for asset", "view_submissions"),
]

for name, codename in asset_permission_strings:
    if not asset_permissions.filter(name=name).exists():
        print("creating permission codename: ", codename)
        Permission(
            name=name,
            content_type=asset_content_type,
            content_type_id=asset_content_type.id,
            codename=codename,
        ).save()

print(permissions_manager.filter(content_type__in=content_types))

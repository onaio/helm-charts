from django.contrib.auth.models import User
from kpi.utils.permissions import grant_default_model_level_perms

print(f"Assigning default permissions for {User.objects.all().count()} users")
for user in User.objects.all():
    grant_default_model_level_perms(user)

python manage.py showmigrations
python manage.py migrate --noinput
python manage.py shell < $PRESET_LOCATION/create_missing_model_permissions.py

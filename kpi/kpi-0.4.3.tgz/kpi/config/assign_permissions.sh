python manage.py shell < $PRESET_LOCATION/assign_default_permissions.py

# Helm Chart: trivy-k8s-scanner

This Helm chart deploys the trivy-k8s-scanner to scan Kubernetes resources images for security vulnerabilities and compliance checks.

## 1. Prerequisites

- Kubernetes cluster
- Helm 3.x

## 2. Directory Structure

Current helm folder structure is as follows:
```
trivy-k8s-scanner/
├── templates/
│   ├── trivy-job.yaml
│   ├── configmap.yaml
│   ├── secret.yaml
│   ├── serviceaccount.yaml
│   ├── rbac.yaml
├── values.yaml
├── Chart.yaml
└── README.md
```

## 3. Installation

To install the Trivy Kubernetes Scanner, follow these steps:

1. Add the Helm repository:

```bash
helm repo add trivy-k8s-scanner https://example.com/charts
```

2. Update the Helm repositories:

```bash
helm repo update
```

3. Install the chart:

```bash
helm install trivy-k8s-scanner trivy-k8s-scanner/trivy-k8s-scanner
```

## 4. Configuration

The following table lists the configurable parameters of the Trivy Kubernetes Scanner chart and their default values:

| Parameter | Description | Default |
|-----------|-------------|---------|
| `imagePullSecrets` | List containing names of secrets relating to docker registries | [] |
| `image.repository` | trivy-k8s-scanner repository | `447036922786.dkr.ecr.eu-central-1.amazonaws.com/onaio/trivy-k8s-scanner` |
| `image.tag` | trivy-k8s-scanner image tag | `v0.1.0` |
| `image.pullPolicy` | trivy-k8s-scanner image pull policy | `IfNotPresent` |
| `schedule` | Schedule on how often the cronjob will run. Default is set to daily. | `0 0 * * *` |
| `trivy.scanType` | Scan type used by trivy i.e. [`k8s`,`image`]| `k8s` |
| `trivy.targetNamespaces` | Namespace to be included in scan. List of namespaces is comma separated |  |
| `trivy.excludeNamespaces` | Namespaces to ignore during scanning.List of namespaces is comma separated |  |
| `trivy.additionalArgs` | Additional arguments to be passed during Trivy scan |  |
| `trivy.skipUpdate` | Prevents downloading/updating trivy-db before   scan. This avoids scan disruption in air-gapped environments | `false` |
| `aws.create` | Create AWS secret based on `accessKeyID` and `accessSecretKey`| `false` |
| `aws.secretName` | Name of AWS secret containing access key and secrets | `aws-secret` |
| `aws.accounts` | List of AWS accounts details of account IDs and regions. Required for scanning ECR images especially in EKS clusters.  |  |
| `docker.create` | Create docker secret based on `username` and `password`| `false` |
| `docker.secretName` | Name of docker secret containing username and password. Utilized for container scans especially in scenarios where max limit is reached. | `docker-secret` |
| `serviceAccount.create` | Creates service-account that has RBAC permissions described in [rbac.yaml](./templates/rbac.yaml) | `true` |
| `serviceAccount.name` | Name of service account | `trivy-sa` |
| `rbac.create` | Sets up RBAC permissions defined in [rbac.yaml](./templates/rbac.yaml) | `true` |
| `resources` | Defined CPU and Memory resource requests and limits. Refer to [values.yaml](./values.yaml) for default values |  |

For more information on how to configure the Trivy Kubernetes Scanner, refer to the [values.yaml](./values.yaml) file.

## 5. Usage

Trivy scan commands can be customized on the `trivy-job.yaml` file. More information on trivy scan scripts can be found on Trivy's official documentation [here](https://aquasecurity.github.io/trivy)

## 6. Uninstallation

To uninstall the Trivy Kubernetes Scanner, run the following command:

```bash
helm uninstall trivy-k8s-scanner -n <NAMESPACE>
```
